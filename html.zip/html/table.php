<?php
require_once 'dbconf.php'; // данные для подключения базы
require_once 'dataheader.php'; // коннект к базе и заглавная строка с основными значениями из базы

// берём из POST число строк для вывода
if(!empty($_POST)) {
	$rows = $_POST['rows'];
} else {
	$rows = 24; // если пост пустой то строк столько
}

/** Собираем пагинацию для таблицы **/
$rec = $count;
if(!isset($_GET['str'])) {
	$str = 0; 
} else {
	$str = $_GET['str'];
	$rows = $_GET['limit'];
}
$start = $str * $rows;
$r = $conn->query("SELECT * FROM data LIMIT $start, $rows");
$n = mysqli_num_rows($r); // возвращаем число рядов

/** Собираем навигацию по стрелочкам **/
$navLine = "<div class='navigation'>";
if( $str == 0 ){
	$navLine .= "<span class='nav' href='table.php?str=0&limit=$rows'>&laquo;</span>";
} else {
	$navLine .= "<a class='nav' href='table.php?str=0&limit=$rows'>&laquo;</a>";	
}
if($str > 0){
	$p = $str - 1;
	$navLine .= "<a class='nav' href='table.php?str=$p&limit=$rows'>НАЗАД</a>";
}
$str++;
if($start + $n < $rec){
	$navLine .= "<a class='nav' href='table.php?str=$str&limit=$rows'>ДАЛЕЕ</a>";
	$navLine .= "<a class='nav' href='table.php?str=".floor($rec/$rows)."&limit=$rows'>&raquo;</a>";
} else {
	$navLine .= "<span class='nav' href='table.php?str=".floor($rec/$rows)."&limit=$rows'>&raquo;</span>";
}
$navLine .= "</div>";

/** Собираем навигацию по страницам **/
$pLine = "<ul class='pagination'>";
for($i = 0; $i < ceil($rec/$rows); $i++){
	if( ($i+1) == $str ){
		$pLine .= "<li><span class='pg'><strong>".$str."</strong></span></li>";
	} else {
		$pLine .= "<li><a class='pg' href='table.php?str=$i&limit=$rows'>".($i+1)."</a></li>";
	}
}
$pLine .= "</ul>";

/** Собираем таблицу **/
$table = "<table id='data' class='alldata'><tr><th>Id</th><th>Date</th><th>Temp1 (&deg;C)</th><th>Temp2 (&deg;C)</th><th>Pressure (Pa)</th><th>Humidity (%)</th></tr>";
for($i = 0; $i < $n; $i++){
	$tt = mysqli_fetch_array($r);
	$t_id = $tt["id"];
	$t_date = $tt["date"];
	$t_tmp1 = $tt["Temp1"];
	$t_tmp2 = $tt["Temp2"];
	$t_hum = $tt["Humidity"];
	$t_prs = $tt["Pressure"];
	$table .= "<tr><td>$t_id</td><td>$t_date</td><td>$t_tmp1</td><td>$t_tmp2</td><td>$t_prs</td><td>$t_hum</td></tr>";
}
$table .= "</table>";

$conn->close();
?>
<!DOCTYPE html>
<html lang="ru-RU">
<head>
	<title>Рисуем графики</title>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8"  />
	<meta name="viewport" content="width=device-width">
	<base href="/">
	<!-- jQuery -->
	<script src="js/jquery-1.12.4.min.js"></script>
	<script src="js/source/jquery.canvaswrapper.js"></script>
	<script src="js/source/jquery.colorhelpers.js"></script>
	<!-- C3 -->
	<link href="c3.css" rel="stylesheet">
	<script src="js/d3.v5.min.js"></script>
	<script src="js/c3.min.js"></script>
	<!-- page style -->
	<link href="style.css" rel="stylesheet">
</head>
<body>
	<div class="main">
		<h3 class="mainLink">Сводная таблица данных</h3>
		<h3 class="mainLink"><a href="serv.php">Управление</a></h3>
		<h3 class="mainLink"><a href="index.php">Графики</a></h3>
		<?php echo $headerLine; ?>
		<form id="form3" action="table.php" method="post">
			<span>Выводить строк: </span>
			<label><input type="radio" name="rows" value="40">40</label>
			<label><input type="radio" name="rows" value="60">60</label>
			<label><input type="radio" name="rows" value="80">80</label>
			<button class="button" type="submit" name="send">Выбрать</button>
		</form>
		<?php echo $navLine; ?>
		<?php echo $pLine; ?>
		<?php echo $table; ?>
		<div class="footer"></div>
	</div>
	<div id="footer">&copy; <?php echo (date('Y'));?></div>
	<script>
		$("#form3").on("submit", function(){
			$.ajax({
				url: 'table.php',
				method: 'post',
				dataType: 'html',
				data: $(this).serialize(),
				success: function(data){
					location.reload();
					$('#message').html(data);
				}
			});
		});
	</script>
	</body>
</html>