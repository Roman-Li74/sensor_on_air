<?php
require_once 'dbconf.php';
// Mysql connect
$conn = new mysqli($host, $username, $password, $dbname);
if($conn->connect_error){
	die("Ошибка: ".$conn->connect_errno . " " . $conn->connect_error);
}

// склоняем числительные
function declination($number, $titles) {	
	$cases = array(2, 0, 1, 1, 1, 2);	
	return $titles[($number%100>4 && $number%100<20) ? 2 : $cases[min($number%10, 5)]];	
}

// Объявляем некоторые переменные
$warn = ''; // Сообщение
$id_min = 1; // Минимальное значение id для выборки из базы

// Собираем заглавную строку
if($result = $conn->query("SELECT date_format(min(date),'%d.%m.%Y %H:%i'),date_format(max(date),'%d.%m.%Y %H:%i'),DateDiff(max(date),min(date)),COUNT(1),max(id) FROM data")){
	for($i = 0; $array[$i] = mysqli_fetch_row($result); $i++);
	array_pop($array);
	$mind = $array[0][0];
	$maxd = $array[0][1];
	$diff = $array[0][2];
	//$s_date = $array[0][3];
	//$e_date = $array[0][4];
	$count = $array[0][3];
	$id_max = $array[0][4];
	$headerLine = "Графики содержат данные за <b>".$diff."</b> ".declination($diff, array('день', 'дня', 'дней'))." c <b>".$mind."</b> по <b>".$maxd."</b> и содержит <b>".$count."</b> записей";
	$result->free();
} else {
	echo "Ошибка: " . $conn->error;
}

// Функция получения массива по интервалу дат
function userGraph($sd,$ed){
	require 'dbconf.php';
	$conn = new mysqli($host, $username, $password, $dbname);
	if($result = $conn->query("SELECT date_format(date, '%d.%m.%Y %H:%i'), Temp1, Temp2, Pressure, Humidity FROM data WHERE date BETWEEN '$sd' AND '$ed'")){
		for($i = 0; $array[$i] = mysqli_fetch_row($result); $i++);
		array_pop($array);
	} else {
		die("Ошибка: ".$conn->connect_errno . " " . $conn->connect_error);
	}
	return $array;
}

// Функция получения последних 48 значений данных
function lastGraph() {
	require 'dbconf.php';
	$conn = new mysqli($host, $username, $password, $dbname);
	if($result = $conn->query("SELECT date_format(date, '%d.%m.%Y %H:%i'), Temp1, Temp2, Pressure, Humidity FROM data ORDER BY id DESC LIMIT 48")){
		for($i = 0; $array[$i] = mysqli_fetch_row($result); $i++);
		array_pop($array);
	} else {
		die('Select Error ('. $conn->errno .')'. $conn->error);
	}
	return $array;
}

// Получение интервала дат из POST и передача их в функцию
if(!empty($_POST)){
	if(!empty($_POST['hs_date']) && !empty($_POST['he_date'])){
		$s_date = date('Y-m-d h:i',strtotime($_POST['hs_date']));
		$e_date = date('Y-m-d h:i',strtotime($_POST['he_date']));
		$warn = $s_date." <-> ".$e_date;
		$graph = userGraph($s_date, $e_date);
	} elseif(!empty($_POST['s_date']) && !empty($_POST['e_date'])){
		$s_date = $_POST['s_date']." 00:00:00";
		$e_date = $_POST['e_date']." 23:59:59";
		if($s_date > $e_date) {
			$warn = "Введите даты в правильном порядке!";
		} else {
			$warn = date('d-m-Y H:i',strtotime($s_date))." <-> ".date('d-m-Y H:i',strtotime($e_date));
			$graph = userGraph($s_date, $e_date);
		}
	} else {
		$warn = "Выберете даты!";
	}
} else {
	$graph = lastGraph(); // График за последние 48 часов
	$warn = "Выберете даты!";
}

// Получакм массивы для графиков из выборки базы		
for($i = 0; $i < count($graph); $i++){
	$dates[] = $graph[$i][0];
	$temp1[] = $graph[$i][1];
	$temp2[] = $graph[$i][2];
	$tempS[] = round(($graph[$i][1] + $graph[$i][2])/2,1);
	$press[] = $graph[$i][3];
	$humid[] = $graph[$i][4];
}

// Берём последние значения датчиков из записи с максимальным id для круговых диаграм
if($result = $conn->query("SELECT Temp1, Temp2, Pressure, Humidity FROM data WHERE id = $id_max")){
	for($i = 0; $arrayLastData[$i] = mysqli_fetch_row($result); $i++);
	array_pop($arrayLastData);
} else {
	die('Select Error ('. $conn->errno .')'. $conn->error);
}
$conn->close();
$result->free();
$midleTemp = round(($arrayLastData[0][0] + $arrayLastData[0][1])/2,1);
$inTemp = $arrayLastData[0][0];
$outTemp = $arrayLastData[0][1];
$singlePress = round(($arrayLastData[0][2]/133.3223684),1);
$singleHumid = $arrayLastData[0][3];
?>
<!DOCTYPE html>
<html lang="ru-RU">
<head>
	<title>Рисуем графики</title>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8"  />
	<meta name="viewport" content="width=device-width">
	<base href="/">
	<!-- jQuery -->
	<script src="js/jquery-1.12.4.min.js"></script>
	<script src="js/source/jquery.canvaswrapper.js"></script>
	<script src="js/source/jquery.colorhelpers.js"></script>
	<!-- C3 -->
	<link href="c3.css" rel="stylesheet">
	<script src="js/d3.v5.min.js"></script>
	<script src="js/c3.min.js"></script>
	<!-- page style -->
	<link href="style.css" rel="stylesheet">
</head>
<body>
	<div class="main">
		<h3 class="mainLink">Графики</h3>
		<h3 class="mainLink"><a href="table.php">Сводная таблица данных</a></h3>
		<h3 class="mainLink"><a href="serv.php">Управление</a></h3>
		<p><?php echo $headerLine; ?></p>
		<div class="form">
			<form id="form" action="index.php" method="post">
				<span class="datePeriod">
					Выбрать интервал дат:
					<input type="date" name="s_date" min="<?php echo date('Y-m-d',strtotime($mind)); ?>" max="<?php echo date('Y-m-d',strtotime($maxd)); ?>">
					<input type="date" name="e_date" min="<?php echo date('Y-m-d',strtotime($mind)); ?>" max="<?php echo date('Y-m-d',strtotime($maxd)); ?>">
				</span>
				<input type="hidden" name="hs_date" value="<?php echo $mind; ?>">
				<input type="hidden" name="he_date" value="<?php echo $maxd; ?>">
				<button class="button dateAll" type="button">График за весь период</button>
				<button class="button" type="reset">Очистить форму</button>
				<button class="button" name="send">Отправить</button>
				<div id="message"><?php echo $warn; ?></div>
			</form>
		</div>
		<div class="lastData">
			<h3>Последние значения датчиков</h3>
			<div id="chart4"></div>
			<div id="chart3"></div>
			<div id="chart2"></div>
			<div id="chart1"></div>
		</div>
		<h3>График значений за период -> <?php echo $warn; ?></h3>
		<div id="chart0"></div>
		<div class="footer"></div>
	</div>
	<div id="footer">&copy; <?php echo (date('Y'));?></div>
		<script>
			/* отправка формы с выбором дат */
			$("button.dateAll").on('click', function(){
				$("input[name='s_date']").val('');
				$("input[name='e_date']").val('');
				$.ajax({
					url: '/index.php',
					method: 'post',
					dataType: 'html',
					data: $(this).serialize(),
					success: function(data){
						$('#message').html(data);
					}
				});
				$("#form").submit();
			});
			$("button[name='send']").on('click', function(){
				$("input[name='hs_date']").val('');
				$("input[name='he_date']").val('');
					$.ajax({
					url: '/index.php',
					method: 'post',
					dataType: 'html',
					data: $(this).serialize(),
					success: function(data){
						$('#message').html(data);
					}
				});
				$("#form").submit();
			});
			$("button[type='reset']").click(function() {
				$("input[name='s_date']").val('');
				$("input[name='e_date']").val('');
				$("input[name='hs_date']").val('');
				$("input[name='he_date']").val('');
			   location.reload();
			});
		</script>	
		<script>
		<?php
		// Пересобираем массивы с данными для скриптов графиков
		// var dates=['Date', dd-mm-yyyy hh:mm, dd-mm-yyyy hh:mm...];
		echo "var dates=['Date',";
		foreach($dates as $val => $e){
			if($val !== array_key_last($dates)){
				echo "'".$e."'".",";	
			} else {
				echo "'".$e."'"."]";
			}
		}
		echo "\n";
		// Пересобираем массивы с данными для скриптов графиков
		// var tempIn=['Temp1', dd, dd, dd, dd...];
		echo "\t\tvar tempIn=['t°C внутри',";
		foreach($temp1 as $val => $e){
			if($val !== array_key_last($temp1)){
				echo $e.",";
			} else {
				echo $e."]";
			}
		}
		echo "\n";
		// Пересобираем массивы с данными для скриптов графиков
		// var tempOut=['Temp2', dd, dd, dd, dd...];
		echo "\t\tvar tempOut=['t°C снаружи',";
		foreach($temp2 as $val => $e){
			if($val !== array_key_last($temp2)){
				echo $e.",";
			} else {
				echo $e."]";
			}
		}
		echo "\n";
		// Пересобираем массивы с данными для скриптов графиков
		// var tempMid=['TempS', dd, dd, dd, dd...];
		echo "\t\tvar tempMid=['t°C средняя',";
		foreach($tempS as $val => $e){
			if($val !== array_key_last($tempS)){
				echo $e.",";
			} else {
				echo $e."]";
			}
		}
		echo "\n";
		// Пересобираем массивы с данными для скриптов графиков		
		// var humi=['Humidity', dd, dd, dd, dd...];
		echo "\t\tvar humi=['Влажность',";
		foreach($humid as $val => $e){
			if($val !== array_key_last($humid)){
				echo $e.",";
			} else {
				echo $e."]";
			}
		}
		echo "\n";
		// Пересобираем массивы с данными для скриптов графиков
		// var press=['Pressure', dd, dd, dd, dd...];
		echo "\t\tvar press=['Pressure',";
		foreach($press as $val => $e){
			if($val !== array_key_last($press)){
				echo round(($e/133.3223684),1).",";
			} else {
				echo round(($e/133.3223684),1)."]";
			}
		}
		echo "\n";
		?>
		/* Общий график */
		var chart0 = c3.generate({
			bindto: '#chart0',
			data: {
				x: 'Date',
				xFormat: '%d.%m.%Y %H:%M',
				columns: [
					tempIn, tempOut, tempMid, humi, press, dates, 
				],
				axes: {
					Temp: 'y',
					Pressure: 'y2',
				},
				types: {
				}
			},
			color: {
				pattern: ['#04B404','#1b4cce','#ce571b40','#0B98A0','#73502b'],
			},
			point: {
				show: false
			},
			grid: {
				x: {
					show: true
				},
				y: {
					show: true
				}
			},
			axis: {
				x: {
					type: 'timeseries',
					tick: {
						format: '%d.%m.%Y %H:%M',
						rotate: -90,
						multiline: false,
					}
				},
				y: {
					label: {
						text: 'Температура / Влажность',
						position: 'outer-middle'
					},
				},
				y2: { 
					label: {
						text: 'Давление',
						position: 'outer-middle'
					},
					show: true,
				}
			}
		});
		/* Диаграмма давления */
		var chart1 = c3.generate({
			bindto: '#chart1',
			data: {
				columns: [
					['Pressure', 0]
				],
				type: 'gauge',				
			},
			gauge:{
				label: {
					format: function(value,ratio){
						return value;
					},
					show: true
				},
				min: 700,
				max: 800,
				units: 'mm',
				width: 45
			},
			color: {
				pattern: ['#73502b'],
				threshhold: {
					unit: 'mm',
					max: 800,
				},
			},
			axis: {
				x: {
					label: {
						text: 'mm',
						position: 'outer-middle'
					},
					show: true,
				},
			},
		});
		setTimeout(function () {
			chart1.load({
				columns: [['Pressure', <?php echo $singlePress; ?>]]
			});
		}, 1000);
		/* Диаграмма влажности */
		var chart2 = c3.generate({
			bindto: '#chart2',
			data: {
				columns: [
					['Humidity', 0]
				],
				type: 'gauge',				
			},
			gauge:{
				label: {
					format: function(value,ratio){
						return value;
					},
					show: true
				},
				min: 0,
				max: 100,
				units: '%',
				width: 45
			},
			color: {
				pattern: ['#0B98A0'],
				threshhold: {
					unit: '%',
					max: 100,
				},
			},
			axis: {
				x: {
					label: {
						text: '%',
						position: 'outer-middle'
					},
					show: true,
				},
			},
		});
		setTimeout(function () {
			chart2.load({
				columns: [['Humidity', <?php echo $singleHumid; ?>]]
			});
		}, 1000);
		/* Диаграмма комнатной температуры */
		var chart3 = c3.generate({
			bindto: '#chart3',
			data: {
				columns: [
					['Temp In', 0]
				],
				type: 'gauge',				
			},
			gauge:{
				label: {
					format: function(value,ratio){
						return value;
					},
					show: true
				},
				min: 0,
				max: 50,
				units: '°C',
				width: 45
			},
			color: {
				pattern: ['#04B404'],
				threshhold: {
					unit: '°C',
					max: 100,
				},
			},
			axis: {
				x: {
					label: {
						text: '°C',
						position: 'outer-middle'
					},
					show: true,
				},
			},
		});
		setTimeout(function () {
			chart3.load({
				columns: [['Temp In', <?php echo $inTemp; ?>]]
			});
		}, 1000);
		/* Диаграмма уличной температуры */
		var chart4 = c3.generate({
			bindto: '#chart4',
			data: {
				columns: [
					['Temp Out', 0]
				],
				type: 'gauge',				
			},
			gauge:{
				label: {
					format: function(value,ratio){
						return value;
					},
					show: true
				},
				min: -50,
				max: 50,
				units: '°C',
				width: 45
			},
			color: {
				pattern: ['#1b4cce'],
				threshhold: {
					unit: '°C',
					max: 100,
				},
			},
			axis: {
				x: {
					label: {
						text: '°C',
						position: 'outer-middle'
					},
					show: true,
				},
			},
		});
		setTimeout(function () {
			chart4.load({
				columns: [['Temp Out', <?php echo $outTemp; ?>]]
			});
		}, 1000);
		</script>
</body>
</html>