<?php
// Mysql connect
$conn = new mysqli($host, $username, $password, $dbname);
if($conn->connect_error){
    die("Ошибка: ".$conn->connect_errno . " " . $conn->connect_error);
}
/** Собираем заголовок **/
if($result = $conn->query("SELECT date_format(min(date),'%d.%m.%Y %H:%i'),date_format(max(date),'%d.%m.%Y %H:%i'),DateDiff(max(date),min(date)),date_format(min(date),'%Y-%m-%d'),date_format(max(date),'%Y-%m-%d'),COUNT(1) FROM data")){
	foreach($result as $row){
		$diff = $row["DateDiff(max(date),min(date))"];
		if($diff <= 4 ){
			$dd = 'дня';
		} elseif($diff >= 101 and $diff <= 104 ){
			$dd = 'дня';
		} else {
			$dd = 'дней';
		}
		$mind = $row["date_format(min(date),'%d.%m.%Y %H:%i')"];
		$maxd = $row["date_format(max(date),'%d.%m.%Y %H:%i')"];
		$s_date = $row["date_format(min(date),'%Y-%m-%d')"];
		$e_date = $row["date_format(max(date),'%Y-%m-%d')"];
		$count = $row["COUNT(1)"];
		$headerLine = "<p>Таблица содержат данные за <strong>";
		$headerLine .= $row["DateDiff(max(date),min(date))"];
		$headerLine .= "</strong> ".$dd." c <strong>";
		$headerLine .= $mind;
		$headerLine .= "</strong> по <strong>";
		$headerLine .= $maxd;
		$headerLine .= "</strong> и содержит <strong>";
		$headerLine .= $count;
		$headerLine .= "</strong> записей</p>";
	}
	$result->free();
} else {
	echo "Ошибка: " . $conn->error;
}
?>