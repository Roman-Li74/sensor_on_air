<?php
$host = "localhost";
$dbname = "py";
$username = "py";
$password = "py_test";
?>