<?php
require_once 'dbconf.php';
// Mysql connect
$conn = new mysqli($host, $username, $password, $dbname);
if($conn->connect_error){
	die("Ошибка: ".$conn->connect_errno . " " . $conn->connect_error);
}

$warn = '';
if(!empty($_POST)) {
	$eng = $_POST['eng'];
	if(empty($_POST['light1'])){
		$light1 = 0;
	} else {
		$light1 = $_POST['light1'];
	}
	if(empty($_POST['light2'])){
		$light2 = 0;
	} else {
		$light2 = $_POST['light2'];
	}
	$serv = $_POST['servo'];
	$warn = $eng."-".$light1."-".$light2."-".$serv;
	if($conn->query("INSERT INTO servo (eng,light1,light2,serv) VALUES ($eng,$light1,$light2,$serv)")){
		$warn .= "<br>Значения добавлены!";
	} else {
		echo ("Ошибка: ".$conn->connect_errno . " " . $conn->connect_error);
	}
} else {
	$warn = "Ожидаем значения!";
}

// Читаем последние значения из базы
if($result = $conn->query("SELECT eng,light1,light2,serv FROM servo ORDER BY id DESC LIMIT 1")){
	foreach($result as $row){
		$eng = $row['eng'];
		$light1 = $row['light1'];
		$light2 = $row['light2'];
		$serv = $row['serv'];
	}
	$result->free();
}

?>
<!DOCTYPE html>
<html lang="ru-RU">
<head>
	<title>Пытаемся управлять</title>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8"  />
	<meta name="viewport" content="width=device-width">
	<base href="/">
	<!-- jQuery -->
	<script src="js/jquery-1.12.4.min.js"></script>
	<script src="js/source/jquery.canvaswrapper.js"></script>
	<script src="js/source/jquery.colorhelpers.js"></script>
	<!-- C3 -->
	<link href="c3.css" rel="stylesheet">
	<script src="js/d3.v5.min.js"></script>
	<script src="js/c3.min.js"></script>
	<!-- page style -->
	<link href="style.css" rel="stylesheet">
</head>
<body>
	<div class="main">
		<h3 class="mainLink">Элементы управления</h3>
		<h3 class="mainLink"><a href="table.php">Сводная таблица данных</a></h3>
		<h3 class="mainLink"><a href="index.php">Графики</a></h3>
		<form id="form2" action="serv.php" method="post">
			<div class="eng block">
				<span>
					<span class="engLabel">Насос</span>
					<span><input type="radio" name="eng" value="1" <?php echo ($eng == 1 ? 'checked' : '');?>>Вкл.</span>
					<span><input type="radio" name="eng" value="0" <?php echo ($eng == 0 ? 'checked' : '');?>>Выкл.</span>
				</span>
				<div class="stateLabel">Текущее состояние</div>
				<div class="state<?php echo ($eng == 1 ? ' on' : ' off');?>"></div>
			</div>
			<div class="light block">
				<span class="lightLabel">Освещение</span>
				<label><input type="checkbox" name="light1" value="1" <?php echo ($light1 == 1 ? 'checked' : '');?>>Лампа 1</label>
				<label><input type="checkbox" name="light2" value="1" <?php echo ($light2 == 1 ? 'checked' : '');?>>Лампа 2</label>
				<div class="stateLabel">Текущее состояние</div>
				<div class="state">
					<div class="lgh1<?php echo ($light1 == 1 ? ' on' : ' off');?>"></div>
					<div class="lgh2<?php echo ($light2 == 1 ? ' on' : ' off');?>"></div>
				</div>
			</div>
			<div class="servo block">
				<span class="servoLabel">Приводы</span>
				<label><input type="radio" name="servo" value="0" <?php echo ($serv == 0 ? 'checked' : '');?>>0&deg;</label>
				<label><input type="radio" name="servo" value="15" <?php echo ($serv == 15 ? 'checked' : '');?>>15&deg;</label>
				<label><input type="radio" name="servo" value="30" <?php echo ($serv == 30 ? 'checked' : '');?>>30&deg;</label>
				<label><input type="radio" name="servo" value="45" <?php echo ($serv == 45 ? 'checked' : '');?>>45&deg;</label>
				<label><input type="radio" name="servo" value="60" <?php echo ($serv == 60 ? 'checked' : '');?>>60&deg;</label>
				<div class="stateLabel">Текущее состояние</div>
				<div class="srv state c<?php echo $serv; ?>"></div>
			</div>
			<div class="clear"></div>
			<button class="button" type="reset">Сброс</button>
			<button class="button" type="submit" name="send">Отправить</button>
		</form>
		<div id="message" class="warn"><?php echo $warn; ?></div>
		<div class="footer"></div>
	</div>
	<div id="footer">&copy; <?php echo (date('Y'));?></div>
	<script>
	$("button[name='send']").on('click', function(){
		$.ajax({
			url: '/serv.php',
			method: 'post',
			dataType: 'html',
			data: $(this).serialize(),
			success: function(data){
				$('#message').html(data);
			}
		});
		$("#form2").submit();
	});

	$("button[type='reset']").click(function() {
		location.reload();
	});
	</script>
</body>
</html>
